package com.cts.bookShopping.service;

import com.cts.bookShopping.bean.userRegistration;

public interface RegisterationService {
	public String setUserDetails(userRegistration userregistration);
}
