package com.cts.bookShopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.Books;
import com.cts.bookShopping.dao.BooksDAO;
import com.cts.bookShopping.dao.CategoryDAO;
@Service("booksService")
@Transactional(propagation = Propagation.SUPPORTS)
public class BooksServiceImpl implements BooksService{

	@Autowired
	private BooksDAO booksDAO;

	@Override
	public String insertBook(Books books) {
		return booksDAO.insertBook(books);
	}

	@Override
	public String deleteBook(String id) {
		// TODO Auto-generated method stub
		return booksDAO.deleteBook(id);
	}

	@Override
	public String updateBook(Books books) {
		// TODO Auto-generated method stub
		return booksDAO.updateBook(books);
	}

	@Override
	public Books getBookById(String id) {
		// TODO Auto-generated method stub
		return booksDAO.getBookById(id);
	}

	@Override
	public List<Books> getAllBook() {
		// TODO Auto-generated method stub
		return booksDAO.getAllBook();
	}

	@Override
	public Books getBookByName(String name) {
		// TODO Auto-generated method stub
		return booksDAO.getBookByName(name);
	}

	@Override
	public List<Books> getDescBook() {
		// TODO Auto-generated method stub
		return booksDAO.getDescBook();
	}

	@Override
	public List<Books> getAscBook() {
		// TODO Auto-generated method stub
		return booksDAO.getAscBook();
	}
	

}
